
## Megan Karbowski

### mkarbows

#### Grader: Eko and Sirseim

| | Points | Comments |
| --- | ---: | --- |
| *Punctuality (4f)* |  | Start Date: 4/27/2017 End Date: 4/28/2017 |
| *Version Control (4e)* |  | 57 commits |
| *Code Style (4c)* |  | Error count: N/A, Error type: N/A |
| *Best Practices (4b)* |  |  |
| *Normals (1c, 2c, 3d)* | 25 |  |
| *Diffuse lighting (1b, 2c, 3d)* | 20 |  |
| *Specular lighting (1b, 2c, 3d)* | 20 |  |
| *Camera (2a, 2b, 3a)* | 22 | Implemented and used, but solely for static viewing volume position (-3) |
| *Unit Tests (4a, 4b)* | 0 | No normal unit tests (-3 —just because normals computation was given as sample code doesn’t mean it shouldn’t be tested), no camera unit tests (-7) |
| **TOTAL** | 87 |
