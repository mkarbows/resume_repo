
## Megan Karbowski

### mkarbows

#### Grader: Eko and Sirseim

| | Points | Comments |
| --- | ---: | --- |
| *Punctuality (4f)* |  | Start Date: 4/28/2017 End Date: 5/5/2017 |
| *Version Control (4e)* |  | 57 commits |
| *Code Style (4c)* |  | Error count: N/A, Error type: N/A |
| *Best Practices (4b)* |  |  |
| *Physics or Tweening (3a, 3b)* | 47 | Generalized position-velocity-acceleration is present, but some avoidable hardcoding (`[1][3]`) seen (-3) |
| *Interaction (1c, 3b, 3d, 4a)* | 45 | Play/pause from sample code spotted, plus “object grabbing” is used for a different effect—just -5 for lack of new interaction code; would have been a bigger deduction if the effect of rotating the individual subparts of the head weren’t there |
| **TOTAL** | 92 |
