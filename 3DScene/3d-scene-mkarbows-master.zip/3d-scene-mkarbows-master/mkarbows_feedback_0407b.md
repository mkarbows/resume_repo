
## Megan Karbowski

### mkarbows

#### Grader: Eko and Sirseim

| | Points | Comments |
| --- | ---: | --- |
| *Punctuality (4f)* |  | Start Date: 4/4/2017 End Date: 4/27/2017 |
| *Version Control (4e)* |  | 57 commits |
| *Code Style (4c)* | -1 | Error count: 3, Error type: no-undef |
| *Best Practices (4b)* |  |  |
| *Matrix Constructor (2a, 3a)* | 5 |  |
| *Matrix Multiplication (2a, 3a)* | 5 |  |
| *Affine Transformations (2a, 3a)* | 12 |  |
| *Projections (2b, 3a)* | 8 |  |
| *WebGL Conversion (3d, 4a)* | 5 |  |
| *Unit Tests (4a, 4b)* | 20 | **Success Rate:** 18/19 **Success Rate %:** 0.95% **Coverage:** 54/66 **Coverage %:** 0.8181818182% ; **|
| *Instance Transformation (1c, 2a, 3d)* | 20 |  |
| *Composite Objects (1c, 2a, 3d)* | 20 |  |
| *Full 3D Scene (1c, 2a, 2b, 3d)* | 5 |  |
| *Load from JSON (extra)* |  |  |
| **TOTAL** | 99 |
