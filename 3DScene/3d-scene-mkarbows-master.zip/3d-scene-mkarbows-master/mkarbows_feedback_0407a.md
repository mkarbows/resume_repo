
## Megan Karbowski

### mkarbows

#### Grader: Eko and Sirseim

| | Points | Comments |
| --- | ---: | --- |
| *Punctuality (4f)* |  | Start Date: 3/27/2017 End Date: 4/4/2017 |
| *Version Control (4e)* |  | 57 commits |
| *Code Style (4c)* | -2 | Error count: 5, Error type: no-undef, lines-around-comment, keyword-spacing |
| *Best Practices (4b)* |  |  |
| *Mesh (1b, 3a, 4a)* | 20 |  |
| *3D Object (1c, 3a, 4a)* | 20 |  |
| *Sphere (1b, 3a)* | 20 |  |
| *Two More Meshes (1b, 3a)* | 20 |  |
| *Unit Tests (4a, 4b)* | 20 | **Success Rate:** 18/19 **Success Rate %:** 0.9473684211% **Coverage:** 84/179 **Coverage %:** 0.469273743% ; **|
| *Extrude function (extra)* |  |  |
| *Lathe function (extra)* |  |  |
| **TOTAL** | 98 |
